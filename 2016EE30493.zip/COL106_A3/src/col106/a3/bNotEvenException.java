package col106.a3;

public class bNotEvenException extends Exception {
    public bNotEvenException() {
        super("bNotEvenException");
    }
}
